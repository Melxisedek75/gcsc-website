# vidIQ YouTube plugin

Private Agent Plugin package for vidIQ-style YouTube planning and optimization.

Current release: `0.1.0`

This release is skills-only. It does not connect to a vidIQ account, YouTube account, or live analytics API. Supply screenshots, exports, or channel data for evidence-based analysis.
